package density.exchange;

import lombok.Data;

@Data
public class PaymentBankICICI implements PaymentBanks{

    String bankName;

}
