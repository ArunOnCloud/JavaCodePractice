package density.exchange;

public class PaymentGatewayFactory {

    PaymentGateway paymentGateway;

    PaymentGateway getPaymentGateway(PaymentType paymentType){

    }
}
enum PaymentType{
    NET_BANKING,
    CARD,
    UPI
}
