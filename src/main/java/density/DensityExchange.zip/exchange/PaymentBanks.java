package density.exchange;

public interface PaymentBanks {

   boolean makePayment(double amount,PaymentType paymentType);
}
